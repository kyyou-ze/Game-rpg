# Changelog

> Catatan perubahan tiap versi.

Status: dokumen awal — lengkapi seiring pengembangan.

## Isi

- (belum diisi)
