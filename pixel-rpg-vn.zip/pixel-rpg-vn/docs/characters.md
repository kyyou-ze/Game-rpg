# Daftar Karakter

> Profil protagonis, Sena, dan karakter pendukung.

Status: dokumen awal — lengkapi seiring pengembangan.

## Isi

- (belum diisi)
