# Game Design Document — Senja yang Tak Terucap

> Dokumen desain induk: gameplay loop, sistem, mekanik.

Status: dokumen awal — lengkapi seiring pengembangan.

## Isi

- (belum diisi)
