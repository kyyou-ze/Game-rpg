# Cerita Lengkap

> Naskah cerita per chapter (lihat juga desain-cerita-dan-gameplay.md).

Status: dokumen awal — lengkapi seiring pengembangan.

## Isi

- (belum diisi)
