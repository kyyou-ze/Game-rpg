# World Building

> Setting sekolah, kota, dan lokasi rumah.

Status: dokumen awal — lengkapi seiring pengembangan.

## Isi

- (belum diisi)
