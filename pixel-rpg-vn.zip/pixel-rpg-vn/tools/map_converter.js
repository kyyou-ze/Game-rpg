#!/usr/bin/env node
/**
 * map_converter.js
 * Konversi file Tiled (.tmx) ke format yang dipakai MapSystem.
 *
 * Status: stub — jalankan `node tools/map_converter.js` setelah logika diisi.
 */

console.log('map_converter.js: belum diimplementasikan.');
