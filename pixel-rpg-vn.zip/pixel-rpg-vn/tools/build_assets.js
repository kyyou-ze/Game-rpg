#!/usr/bin/env node
/**
 * build_assets.js
 * Optimasi/kompres aset sebelum build produksi.
 *
 * Status: stub — jalankan `node tools/build_assets.js` setelah logika diisi.
 */

console.log('build_assets.js: belum diimplementasikan.');
