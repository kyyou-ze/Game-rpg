#!/usr/bin/env node
/**
 * export_dialogue.js
 * Ekspor dialogue/*.json ke format lain (mis. CSV untuk review naskah).
 *
 * Status: stub — jalankan `node tools/export_dialogue.js` setelah logika diisi.
 */

console.log('export_dialogue.js: belum diimplementasikan.');
