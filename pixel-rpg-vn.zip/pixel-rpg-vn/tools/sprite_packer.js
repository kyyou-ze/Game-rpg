#!/usr/bin/env node
/**
 * sprite_packer.js
 * Menggabungkan sprite individual menjadi spritesheet.
 *
 * Status: stub — jalankan `node tools/sprite_packer.js` setelah logika diisi.
 */

console.log('sprite_packer.js: belum diimplementasikan.');
