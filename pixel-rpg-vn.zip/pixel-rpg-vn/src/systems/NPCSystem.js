/**
 * NPCSystem
 * Perilaku dan state tiap NPC.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class NPCSystem {
  constructor(...args) {
    this.args = args;
  }


}
