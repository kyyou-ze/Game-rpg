/**
 * NotificationSystem
 * Toast/notifikasi dalam game.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class NotificationSystem {
  constructor(...args) {
    this.args = args;
  }


}
