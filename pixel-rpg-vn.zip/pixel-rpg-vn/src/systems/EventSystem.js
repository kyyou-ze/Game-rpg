/**
 * EventSystem
 * Event bus global antar sistem.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class EventSystem {
  constructor(...args) {
    this.args = args;
  }


}
