/**
 * SaveSystem
 * Serialisasi state game untuk disimpan.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class SaveSystem {
  constructor(...args) {
    this.args = args;
  }


}
