/**
 * WeatherSystem
 * Cuaca (hujan di Chapter 4, dsb).
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class WeatherSystem {
  constructor(...args) {
    this.args = args;
  }


}
