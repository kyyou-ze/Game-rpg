/**
 * RelationshipSystem
 * Mengelola tiga variabel utama (Trust, Affinity, Courage) dan
 * kumpulan flag/switch memory (SW_LangitSore, dsb). Sistem lain
 * (DialogueSystem, EndingSystem) membaca/menulis lewat kelas ini
 * supaya ada satu sumber kebenaran untuk state hubungan.
 */
export default class RelationshipSystem {
  constructor(initialState = {}) {
    this.trust = initialState.trust ?? 0;
    this.affinity = initialState.affinity ?? 0;
    this.courage = initialState.courage ?? 0;
    this.flags = { ...(initialState.flags || {}) };
  }

  add(variable, amount) {
    if (!(variable in this)) {
      console.warn(`RelationshipSystem: variabel "${variable}" tidak dikenal`);
      return;
    }
    this[variable] = Math.max(0, this[variable] + amount);
  }

  setFlag(name, value = true) {
    this.flags[name] = value;
  }

  hasFlag(name) {
    return !!this.flags[name];
  }

  toJSON() {
    return {
      trust: this.trust,
      affinity: this.affinity,
      courage: this.courage,
      flags: { ...this.flags }
    };
  }
}
