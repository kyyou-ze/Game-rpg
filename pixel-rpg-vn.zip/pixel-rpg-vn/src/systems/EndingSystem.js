import endingsData from '../data/endings.json';

/**
 * EndingSystem
 * Mengevaluasi RelationshipSystem di akhir Chapter 5 dan menentukan
 * ending mana yang cocok, berdasarkan aturan di data/endings.json.
 * Urutan pengecekan penting: dari syarat paling tinggi ke default.
 */
export default class EndingSystem {
  static resolve(relationship) {
    const { trust, affinity, courage, flags } = relationship;

    const trueHappy = endingsData.true_happy.require;
    if (
      trust >= trueHappy.trust_min &&
      affinity >= trueHappy.affinity_min &&
      courage >= trueHappy.courage_min &&
      trueHappy.switches.every((flag) => flags[flag])
    ) {
      return 'true_happy';
    }

    const happy = endingsData.happy.require;
    if (trust >= happy.trust_min && affinity >= happy.affinity_min) {
      return 'happy';
    }

    const bittersweet = endingsData.bittersweet.require;
    if (trust >= bittersweet.trust_min && affinity >= bittersweet.affinity_min) {
      return 'bittersweet';
    }

    return 'sad';
  }

  static sceneKeyFor(endingId) {
    const map = {
      true_happy: 'ending-true',
      happy: 'ending-good',
      bittersweet: 'ending-normal',
      sad: 'ending-bad'
    };
    return map[endingId] || 'ending-bad';
  }
}
