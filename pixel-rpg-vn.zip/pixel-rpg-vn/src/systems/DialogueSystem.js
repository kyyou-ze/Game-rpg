/**
 * DialogueSystem
 * Menjalankan satu "script" dialog: array baris berurutan yang bisa
 * berupa teks biasa atau titik pilihan (choice). Dipakai oleh semua
 * scene VN (Rooftop, dst) dan diberi referensi ke RelationshipSystem
 * supaya pilihan bisa langsung mengubah Trust/Affinity/Courage/flag.
 *
 * Format satu baris script:
 *   { speaker: 'Sena', text: '...' }
 *   { choice: [
 *       { label: '...', effects: [{ variable: 'affinity', amount: 1 }], next: 'lanjut biasa' },
 *       { label: '...', effects: [], flags: ['SW_LangitSore'] }
 *     ] }
 */
export default class DialogueSystem {
  constructor(scene, relationship) {
    this.scene = scene;
    this.relationship = relationship;
    this.script = [];
    this.index = 0;
    this.onLine = null;   // callback(line) -> render teks
    this.onChoice = null; // callback(choiceLine) -> render pilihan
    this.onEnd = null;    // callback() -> script selesai
  }

  load(script) {
    this.script = script;
    this.index = 0;
    return this;
  }

  start() {
    this._advance();
  }

  choose(optionIndex) {
    const line = this.script[this.index];
    if (!line || !line.choice) return;

    const option = line.choice[optionIndex];
    if (!option) return;

    (option.effects || []).forEach(({ variable, amount }) => {
      this.relationship.add(variable, amount);
    });
    (option.flags || []).forEach((flag) => this.relationship.setFlag(flag, true));

    this.index += 1;
    this._advance();
  }

  _advance() {
    const line = this.script[this.index];

    if (!line) {
      this.onEnd && this.onEnd();
      return;
    }

    if (line.choice) {
      this.onChoice && this.onChoice(line);
      return; // menunggu choose() dipanggil dari UI
    }

    this.onLine && this.onLine(line);
    this.index += 1;
  }

  next() {
    this._advance();
  }
}
