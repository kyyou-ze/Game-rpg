/**
 * CutsceneSystem
 * Memutar urutan cutscene non-interaktif.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class CutsceneSystem {
  constructor(...args) {
    this.args = args;
  }


}
