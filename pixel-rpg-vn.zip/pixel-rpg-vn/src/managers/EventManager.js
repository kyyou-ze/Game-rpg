/**
 * EventManager
 * Trigger event map (masuk area, dsb).
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class EventManager {
  constructor(...args) {
    this.args = args;
  }


}
