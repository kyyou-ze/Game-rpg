/**
 * TransitionManager
 * Efek transisi fade/wipe antar scene.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class TransitionManager {
  constructor(...args) {
    this.args = args;
  }


}
