/**
 * AnimationManager
 * Registrasi animasi sprite karakter.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class AnimationManager {
  constructor(...args) {
    this.args = args;
  }


}
