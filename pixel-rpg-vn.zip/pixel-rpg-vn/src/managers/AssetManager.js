/**
 * AssetManager
 * Registrasi path aset (sprite, tileset, audio, portrait).
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class AssetManager {
  constructor(...args) {
    this.args = args;
  }


}
