/**
 * UIManager
 * Menampilkan/menyembunyikan komponen UI global.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class UIManager {
  constructor(...args) {
    this.args = args;
  }


}
