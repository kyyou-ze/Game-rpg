/**
 * MusicManager
 * Crossfade dan playlist BGM per scene.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class MusicManager {
  constructor(...args) {
    this.args = args;
  }


}
