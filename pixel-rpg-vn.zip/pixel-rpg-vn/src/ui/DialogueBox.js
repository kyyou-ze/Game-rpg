/**
 * DialogueBox
 * Kotak teks dialog sederhana berbasis Phaser GameObjects:
 * nama pembicara + isi teks + indikator "lanjut".
 */
export default class DialogueBox {
  constructor(scene) {
    this.scene = scene;
    const { width, height } = scene.scale;

    this.container = scene.add.container(0, height - 110);

    const bg = scene.add.rectangle(width / 2, 55, width - 20, 100, 0x000000, 0.75)
      .setStrokeStyle(2, 0xffffff, 0.4);

    this.nameText = scene.add.text(20, 15, '', {
      fontSize: '14px',
      color: '#ffd479',
      fontStyle: 'bold'
    });

    this.bodyText = scene.add.text(20, 40, '', {
      fontSize: '14px',
      color: '#ffffff',
      wordWrap: { width: width - 60 }
    });

    this.continueHint = scene.add.text(width - 90, 85, '▶ lanjut', {
      fontSize: '11px',
      color: '#aaaaaa'
    });

    this.container.add([bg, this.nameText, this.bodyText, this.continueHint]);
    this.hide();
  }

  show(speaker, text) {
    this.container.setVisible(true);
    this.nameText.setText(speaker || '');
    this.bodyText.setText(text || '');
  }

  hide() {
    this.container.setVisible(false);
  }
}
