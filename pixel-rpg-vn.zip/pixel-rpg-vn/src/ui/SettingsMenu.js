/**
 * SettingsMenu
 * Pengaturan volume, teks, kontrol.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class SettingsMenu {
  constructor(...args) {
    this.args = args;
  }


}
