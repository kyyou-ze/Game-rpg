/**
 * InventoryUI
 * Tampilan item (opsional).
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class InventoryUI {
  constructor(...args) {
    this.args = args;
  }


}
