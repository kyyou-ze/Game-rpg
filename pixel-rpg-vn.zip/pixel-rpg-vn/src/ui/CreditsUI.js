/**
 * CreditsUI
 * Layar kredit.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class CreditsUI {
  constructor(...args) {
    this.args = args;
  }


}
