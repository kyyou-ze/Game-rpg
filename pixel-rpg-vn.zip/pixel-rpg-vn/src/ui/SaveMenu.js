/**
 * SaveMenu
 * UI slot simpan.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class SaveMenu {
  constructor(...args) {
    this.args = args;
  }


}
