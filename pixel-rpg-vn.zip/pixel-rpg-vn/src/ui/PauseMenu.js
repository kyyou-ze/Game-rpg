/**
 * PauseMenu
 * Menu jeda dalam permainan.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class PauseMenu {
  constructor(...args) {
    this.args = args;
  }


}
