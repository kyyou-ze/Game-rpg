/**
 * RelationshipUI
 * Indikator Trust/Affinity/Courage (opsional, bisa disembunyikan agar tidak terasa seperti 'skor').
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class RelationshipUI {
  constructor(...args) {
    this.args = args;
  }


}
