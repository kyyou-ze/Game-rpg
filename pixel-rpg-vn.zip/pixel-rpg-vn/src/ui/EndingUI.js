/**
 * EndingUI
 * Layar penutup tiap ending.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class EndingUI {
  constructor(...args) {
    this.args = args;
  }


}
