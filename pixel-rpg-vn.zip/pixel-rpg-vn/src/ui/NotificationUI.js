/**
 * NotificationUI
 * Tampilan toast notifikasi.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class NotificationUI {
  constructor(...args) {
    this.args = args;
  }


}
