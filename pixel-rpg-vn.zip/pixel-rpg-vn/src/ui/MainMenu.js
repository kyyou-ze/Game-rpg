/**
 * MainMenu
 * Layar menu utama.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class MainMenu {
  constructor(...args) {
    this.args = args;
  }


}
