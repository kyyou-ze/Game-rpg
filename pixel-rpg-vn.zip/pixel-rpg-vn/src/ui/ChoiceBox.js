/**
 * ChoiceBox
 * Menampilkan daftar tombol pilihan dialog (Show Choices ala RPG Maker).
 * Memanggil onSelect(index) saat salah satu opsi diklik/ditekan.
 */
export default class ChoiceBox {
  constructor(scene) {
    this.scene = scene;
    this.container = scene.add.container(0, 0);
    this.buttons = [];
    this.hide();
  }

  show(options, onSelect) {
    this.clear();
    const { width, height } = this.scene.scale;
    const startY = height - 100 - options.length * 34;

    options.forEach((option, i) => {
      const y = startY + i * 34;
      const bg = this.scene.add.rectangle(width / 2, y, width - 60, 28, 0x222244, 0.9)
        .setStrokeStyle(1, 0xffffff, 0.5)
        .setInteractive({ useHandCursor: true });

      const label = this.scene.add.text(width / 2, y, option.label, {
        fontSize: '13px',
        color: '#ffffff'
      }).setOrigin(0.5);

      bg.on('pointerover', () => bg.setFillStyle(0x33335a, 0.9));
      bg.on('pointerout', () => bg.setFillStyle(0x222244, 0.9));
      bg.on('pointerdown', () => onSelect(i));

      this.buttons.push(bg, label);
      this.container.add([bg, label]);
    });

    this.container.setVisible(true);
  }

  clear() {
    this.buttons.forEach((obj) => obj.destroy());
    this.buttons = [];
  }

  hide() {
    this.clear();
    this.container.setVisible(false);
  }
}
