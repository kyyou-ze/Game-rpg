/**
 * QuestUI
 * Tampilan daftar event/quest opsional.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class QuestUI {
  constructor(...args) {
    this.args = args;
  }


}
