/**
 * LoadMenu
 * UI slot muat.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class LoadMenu {
  constructor(...args) {
    this.args = args;
  }


}
