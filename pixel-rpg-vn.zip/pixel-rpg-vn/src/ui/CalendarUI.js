/**
 * CalendarUI
 * Tampilan kalender in-game.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class CalendarUI {
  constructor(...args) {
    this.args = args;
  }


}
