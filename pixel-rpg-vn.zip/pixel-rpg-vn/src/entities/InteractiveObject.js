/**
 * InteractiveObject
 * Objek map yang memicu event saat diinteraksi (vending machine, dsb).
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class InteractiveObject {
  constructor(...args) {
    this.args = args;
  }


}
