/**
 * Player
 * Entitas pemain: posisi, arah hadap, animasi jalan.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class Player {
  constructor(...args) {
    this.args = args;
  }


}
