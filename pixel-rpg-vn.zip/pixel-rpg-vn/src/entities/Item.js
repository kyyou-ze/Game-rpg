/**
 * Item
 * Objek item yang bisa diambil (opsional).
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class Item {
  constructor(...args) {
    this.args = args;
  }


}
