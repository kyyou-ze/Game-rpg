/**
 * Character
 * Kelas dasar bersama Player & NPC.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class Character {
  constructor(...args) {
    this.args = args;
  }


}
