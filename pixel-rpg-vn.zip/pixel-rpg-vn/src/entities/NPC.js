/**
 * NPC
 * Entitas NPC dasar dengan area interaksi.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class NPC {
  constructor(...args) {
    this.args = args;
  }


}
