/**
 * Door
 * Objek pintu/transisi antar map.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class Door {
  constructor(...args) {
    this.args = args;
  }


}
