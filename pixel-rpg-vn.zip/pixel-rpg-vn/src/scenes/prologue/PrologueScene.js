import Phaser from 'phaser';

/**
 * PrologueScene
 * Scene pembuka sebelum Chapter 1.
 *
 * Status: stub scene — siap diisi tilemap, NPC, dan event dialog.
 */
export default class PrologueScene extends Phaser.Scene {
  constructor() {
    super({ key: 'prologue' });
  }

  preload() {
    // TODO: load tileset/tilemap/sprite khusus scene ini
  }

  create() {
    // TODO: bangun map, spawn player, daftarkan NPC/event interaksi
    this.add.text(16, 16, 'PrologueScene (stub)', { fontSize: '16px', color: '#ffffff' });
  }

  update() {
    // TODO: update pergerakan player & animasi
  }
}
