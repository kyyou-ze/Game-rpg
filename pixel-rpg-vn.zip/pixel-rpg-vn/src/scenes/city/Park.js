import Phaser from 'phaser';

/**
 * Park
 * Scene Park — folder city.
 *
 * Status: stub scene — siap diisi tilemap, NPC, dan event dialog.
 */
export default class Park extends Phaser.Scene {
  constructor() {
    super({ key: 'park' });
  }

  preload() {
    // TODO: load tileset/tilemap/sprite khusus scene ini
  }

  create() {
    // TODO: bangun map, spawn player, daftarkan NPC/event interaksi
    this.add.text(16, 16, 'Park (stub)', { fontSize: '16px', color: '#ffffff' });
  }

  update() {
    // TODO: update pergerakan player & animasi
  }
}
