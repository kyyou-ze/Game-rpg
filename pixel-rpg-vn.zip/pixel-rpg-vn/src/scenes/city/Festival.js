import Phaser from 'phaser';
import DialogueSystem from '../../systems/DialogueSystem.js';
import DialogueBox from '../../ui/DialogueBox.js';
import ChoiceBox from '../../ui/ChoiceBox.js';
import chapter4 from '../../data/dialogue/chapter4.json';
import SaveManager from '../../core/SaveManager.js';
import { SCENE_KEYS } from '../../core/Constants.js';

export default class Festival extends Phaser.Scene {
  constructor() {
    super({ key: SCENE_KEYS.FESTIVAL });
  }

  create() {
    this.add.rectangle(0, 0, this.scale.width, this.scale.height, 0x664466).setOrigin(0);
    this.add.text(20, 20, 'Festival Sekolah — Chapter 4', { fontSize: '14px', color: '#ffffff' });

    const relationship = this.registry.get('relationship');

    this.dialogueBox = new DialogueBox(this);
    this.choiceBox = new ChoiceBox(this);
    this.dialogue = new DialogueSystem(this, relationship);
    this.dialogue.load(chapter4.festival);

    this.dialogue.onLine = (line) => {
      this.choiceBox.hide();
      this.dialogueBox.show(line.speaker, line.text);
    };

    this.dialogue.onChoice = (line) => {
      this.dialogueBox.hide();
      this.choiceBox.show(line.choice, (i) => {
        // Titik pilihan "memory payoff": bonus hanya berlaku kalau SW_LangitSore ON
        const pickedRooftop = i === 1;
        if (pickedRooftop) {
          if (relationship.hasFlag('SW_LangitSore')) {
            relationship.add('affinity', 2);
            relationship.add('trust', 1);
          }
        }
        this.dialogue.choose(i);
      });
    };

    this.dialogue.onEnd = () => {
      this.dialogueBox.hide();
      this.choiceBox.hide();
      SaveManager.save({ chapter: 4, ...relationship.toJSON() });
      this.time.delayedCall(400, () => this.scene.start(SCENE_KEYS.ROOFTOP));
    };

    this.input.on('pointerdown', () => this.dialogue.next());
    this.dialogue.start();
  }
}
