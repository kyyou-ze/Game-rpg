import Phaser from 'phaser';

/**
 * Cafe
 * Scene Cafe — folder city.
 *
 * Status: stub scene — siap diisi tilemap, NPC, dan event dialog.
 */
export default class Cafe extends Phaser.Scene {
  constructor() {
    super({ key: 'cafe' });
  }

  preload() {
    // TODO: load tileset/tilemap/sprite khusus scene ini
  }

  create() {
    // TODO: bangun map, spawn player, daftarkan NPC/event interaksi
    this.add.text(16, 16, 'Cafe (stub)', { fontSize: '16px', color: '#ffffff' });
  }

  update() {
    // TODO: update pergerakan player & animasi
  }
}
