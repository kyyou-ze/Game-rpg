import Phaser from 'phaser';

/**
 * ShoppingStreet
 * Scene ShoppingStreet — folder city.
 *
 * Status: stub scene — siap diisi tilemap, NPC, dan event dialog.
 */
export default class ShoppingStreet extends Phaser.Scene {
  constructor() {
    super({ key: 'shopping-street' });
  }

  preload() {
    // TODO: load tileset/tilemap/sprite khusus scene ini
  }

  create() {
    // TODO: bangun map, spawn player, daftarkan NPC/event interaksi
    this.add.text(16, 16, 'ShoppingStreet (stub)', { fontSize: '16px', color: '#ffffff' });
  }

  update() {
    // TODO: update pergerakan player & animasi
  }
}
