import Phaser from 'phaser';

/**
 * Shrine
 * Scene Shrine — folder city.
 *
 * Status: stub scene — siap diisi tilemap, NPC, dan event dialog.
 */
export default class Shrine extends Phaser.Scene {
  constructor() {
    super({ key: 'shrine' });
  }

  preload() {
    // TODO: load tileset/tilemap/sprite khusus scene ini
  }

  create() {
    // TODO: bangun map, spawn player, daftarkan NPC/event interaksi
    this.add.text(16, 16, 'Shrine (stub)', { fontSize: '16px', color: '#ffffff' });
  }

  update() {
    // TODO: update pergerakan player & animasi
  }
}
