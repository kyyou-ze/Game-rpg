import Phaser from 'phaser';
import { SCENE_KEYS } from '../../core/Constants.js';

export default class PreloadScene extends Phaser.Scene {
  constructor() {
    super({ key: SCENE_KEYS.PRELOAD });
  }

  preload() {
    // TODO: load spritesheet/tileset asli saat sudah tersedia di public/assets
    const { width, height } = this.scale;
    const loadingText = this.add.text(width / 2, height / 2, 'Memuat...', {
      fontSize: '16px',
      color: '#ffffff'
    }).setOrigin(0.5);
    this._loadingText = loadingText;
  }

  create() {
    this.scene.start(SCENE_KEYS.MAIN_MENU);
  }
}
