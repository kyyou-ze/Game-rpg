import Phaser from 'phaser';
import RelationshipSystem from '../../systems/RelationshipSystem.js';
import SaveManager from '../../core/SaveManager.js';
import { SCENE_KEYS } from '../../core/Constants.js';

export default class BootScene extends Phaser.Scene {
  constructor() {
    super({ key: SCENE_KEYS.BOOT });
  }

  create() {
    const saved = SaveManager.load() || SaveManager.defaultState();
    this.registry.set('relationship', new RelationshipSystem(saved));
    this.registry.set('chapter', saved.chapter || 1);

    this.scene.start(SCENE_KEYS.PRELOAD);
  }
}
