import Phaser from 'phaser';

/**
 * SplashScene
 * Scene SplashScene — folder menu.
 *
 * Status: stub scene — siap diisi tilemap, NPC, dan event dialog.
 */
export default class SplashScene extends Phaser.Scene {
  constructor() {
    super({ key: 'splash' });
  }

  preload() {
    // TODO: load tileset/tilemap/sprite khusus scene ini
  }

  create() {
    // TODO: bangun map, spawn player, daftarkan NPC/event interaksi
    this.add.text(16, 16, 'SplashScene (stub)', { fontSize: '16px', color: '#ffffff' });
  }

  update() {
    // TODO: update pergerakan player & animasi
  }
}
