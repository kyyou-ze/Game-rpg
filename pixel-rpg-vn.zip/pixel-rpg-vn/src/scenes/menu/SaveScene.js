import Phaser from 'phaser';

/**
 * SaveScene
 * Scene SaveScene — folder menu.
 *
 * Status: stub scene — siap diisi tilemap, NPC, dan event dialog.
 */
export default class SaveScene extends Phaser.Scene {
  constructor() {
    super({ key: 'save' });
  }

  preload() {
    // TODO: load tileset/tilemap/sprite khusus scene ini
  }

  create() {
    // TODO: bangun map, spawn player, daftarkan NPC/event interaksi
    this.add.text(16, 16, 'SaveScene (stub)', { fontSize: '16px', color: '#ffffff' });
  }

  update() {
    // TODO: update pergerakan player & animasi
  }
}
