import Phaser from 'phaser';

/**
 * LoadScene
 * Scene LoadScene — folder menu.
 *
 * Status: stub scene — siap diisi tilemap, NPC, dan event dialog.
 */
export default class LoadScene extends Phaser.Scene {
  constructor() {
    super({ key: 'load' });
  }

  preload() {
    // TODO: load tileset/tilemap/sprite khusus scene ini
  }

  create() {
    // TODO: bangun map, spawn player, daftarkan NPC/event interaksi
    this.add.text(16, 16, 'LoadScene (stub)', { fontSize: '16px', color: '#ffffff' });
  }

  update() {
    // TODO: update pergerakan player & animasi
  }
}
