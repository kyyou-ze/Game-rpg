import Phaser from 'phaser';
import { SCENE_KEYS } from '../../core/Constants.js';

export default class MainMenuScene extends Phaser.Scene {
  constructor() {
    super({ key: SCENE_KEYS.MAIN_MENU });
  }

  create() {
    const { width, height } = this.scale;
    this.add.rectangle(0, 0, width, height, 0x1a1a2e).setOrigin(0);

    this.add.text(width / 2, height / 2 - 40, 'Senja yang Tak Terucap', {
      fontSize: '22px',
      color: '#ffd479',
      fontStyle: 'bold'
    }).setOrigin(0.5);

    const startBtn = this.add.text(width / 2, height / 2 + 20, '[ Mulai Cerita ]', {
      fontSize: '16px',
      color: '#ffffff'
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });

    startBtn.on('pointerover', () => startBtn.setColor('#ffd479'));
    startBtn.on('pointerout', () => startBtn.setColor('#ffffff'));
    startBtn.on('pointerdown', () => this.scene.start(SCENE_KEYS.CLASSROOM));
  }
}
