import Phaser from 'phaser';

/**
 * SecretEnding
 * Scene SecretEnding — folder endings.
 *
 * Status: stub scene — siap diisi tilemap, NPC, dan event dialog.
 */
export default class SecretEnding extends Phaser.Scene {
  constructor() {
    super({ key: 'ending-secret' });
  }

  preload() {
    // TODO: load tileset/tilemap/sprite khusus scene ini
  }

  create() {
    // TODO: bangun map, spawn player, daftarkan NPC/event interaksi
    this.add.text(16, 16, 'SecretEnding (stub)', { fontSize: '16px', color: '#ffffff' });
  }

  update() {
    // TODO: update pergerakan player & animasi
  }
}
