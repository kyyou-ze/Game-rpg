import Phaser from 'phaser';
import SaveManager from '../../core/SaveManager.js';

export default class BadEnding extends Phaser.Scene {
  constructor() {
    super({ key: 'ending-bad' });
  }

  create() {
    this.add.rectangle(0, 0, this.scale.width, this.scale.height, 0x555577).setOrigin(0);
    this.add.text(this.scale.width / 2, 40, 'SAD END', {
      fontSize: '18px', color: '#ffffff', fontStyle: 'bold'
    }).setOrigin(0.5);

    const lines = [
      'Kalian lulus sekolah. Keluarga Sena pindah kota tak lama setelahnya.',
      'Kalian tidak pernah benar-benar dekat.',
      'Aku baru sadar... selama ini dia sudah berkali-kali mencoba mendekat.',
      'Yang tidak pernah mengerti ternyata adalah aku.',
      '— TAMAT —'
    ];

    this.add.text(40, 90, lines.join('\n\n'), {
      fontSize: '13px', color: '#ffffff', wordWrap: { width: this.scale.width - 80 }
    });

    this._addRestartButton();
  }

  _addRestartButton() {
    const btn = this.add.text(this.scale.width / 2, this.scale.height - 30, '[ Kembali ke Menu ]', {
      fontSize: '13px', color: '#ffffff'
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });

    btn.on('pointerdown', () => {
      SaveManager.clear();
      this.scene.start('main-menu');
    });
  }
}
