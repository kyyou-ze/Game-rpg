import Phaser from 'phaser';
import SaveManager from '../../core/SaveManager.js';

export default class GoodEnding extends Phaser.Scene {
  constructor() {
    super({ key: 'ending-good' });
  }

  create() {
    this.add.rectangle(0, 0, this.scale.width, this.scale.height, 0xffe0a3).setOrigin(0);
    this.add.text(this.scale.width / 2, 40, 'HAPPY END', {
      fontSize: '18px', color: '#3a2a1a', fontStyle: 'bold'
    }).setOrigin(0.5);

    const lines = [
      'Hubungan kalian tumbuh dekat sepanjang semester — saling paham tanpa banyak kata.',
      'Kamu tidak pernah benar-benar mengucapkan perasaanmu, tapi rasanya tidak perlu.',
      'Sena tersenyum lebih sering sekarang, dan itu sudah cukup jadi jawaban.',
      '— TAMAT —'
    ];

    this.add.text(40, 90, lines.join('\n\n'), {
      fontSize: '13px', color: '#3a2a1a', wordWrap: { width: this.scale.width - 80 }
    });

    this._addRestartButton();
  }

  _addRestartButton() {
    const btn = this.add.text(this.scale.width / 2, this.scale.height - 30, '[ Kembali ke Menu ]', {
      fontSize: '13px', color: '#3a2a1a'
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });

    btn.on('pointerdown', () => {
      SaveManager.clear();
      this.scene.start('main-menu');
    });
  }
}
