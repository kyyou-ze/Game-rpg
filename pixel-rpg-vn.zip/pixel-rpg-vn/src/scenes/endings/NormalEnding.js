import Phaser from 'phaser';
import SaveManager from '../../core/SaveManager.js';

export default class NormalEnding extends Phaser.Scene {
  constructor() {
    super({ key: 'ending-normal' });
  }

  create() {
    this.add.rectangle(0, 0, this.scale.width, this.scale.height, 0xb3b3cc).setOrigin(0);
    this.add.text(this.scale.width / 2, 40, 'BITTERSWEET END', {
      fontSize: '18px', color: '#1a1a2e', fontStyle: 'bold'
    }).setOrigin(0.5);

    const lines = [
      'Kalian jadi teman baik, saling mendukung lewat masa-masa sulit.',
      'Tapi momen untuk melangkah lebih jauh tidak pernah benar-benar datang.',
      'Tidak ada yang salah — hanya momentum yang lewat begitu saja.',
      '— TAMAT —'
    ];

    this.add.text(40, 90, lines.join('\n\n'), {
      fontSize: '13px', color: '#1a1a2e', wordWrap: { width: this.scale.width - 80 }
    });

    this._addRestartButton();
  }

  _addRestartButton() {
    const btn = this.add.text(this.scale.width / 2, this.scale.height - 30, '[ Kembali ke Menu ]', {
      fontSize: '13px', color: '#1a1a2e'
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });

    btn.on('pointerdown', () => {
      SaveManager.clear();
      this.scene.start('main-menu');
    });
  }
}
