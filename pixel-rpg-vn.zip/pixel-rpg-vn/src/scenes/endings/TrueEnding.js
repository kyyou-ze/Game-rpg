import Phaser from 'phaser';
import SaveManager from '../../core/SaveManager.js';

export default class TrueEnding extends Phaser.Scene {
  constructor() {
    super({ key: 'ending-true' });
  }

  create() {
    this.add.rectangle(0, 0, this.scale.width, this.scale.height, 0xffcf8f).setOrigin(0);
    this.add.text(this.scale.width / 2, 40, 'TRUE HAPPY END', {
      fontSize: '18px', color: '#3a2a1a', fontStyle: 'bold'
    }).setOrigin(0.5);

    const lines = [
      'Di atap sekolah, saat langit berubah jingga, kamu akhirnya mengatakannya.',
      'Sena diam sesaat — lalu tersenyum tulus, senyum yang sama seperti hari itu.',
      '"Aku juga," katanya pelan.',
      'Kalian duduk berdua menatap matahari terbenam, seperti pertama kali kalian bertemu di tempat ini.',
      '— TAMAT —'
    ];

    this.add.text(40, 90, lines.join('\n\n'), {
      fontSize: '13px', color: '#3a2a1a', wordWrap: { width: this.scale.width - 80 }
    });

    this._addRestartButton();
  }

  _addRestartButton() {
    const btn = this.add.text(this.scale.width / 2, this.scale.height - 30, '[ Kembali ke Menu ]', {
      fontSize: '13px', color: '#3a2a1a'
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });

    btn.on('pointerdown', () => {
      SaveManager.clear();
      this.scene.start('main-menu');
    });
  }
}
