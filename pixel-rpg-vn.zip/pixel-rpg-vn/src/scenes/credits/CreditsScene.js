import Phaser from 'phaser';

/**
 * CreditsScene
 * Layar kredit akhir.
 *
 * Status: stub scene — siap diisi tilemap, NPC, dan event dialog.
 */
export default class CreditsScene extends Phaser.Scene {
  constructor() {
    super({ key: 'credits' });
  }

  preload() {
    // TODO: load tileset/tilemap/sprite khusus scene ini
  }

  create() {
    // TODO: bangun map, spawn player, daftarkan NPC/event interaksi
    this.add.text(16, 16, 'CreditsScene (stub)', { fontSize: '16px', color: '#ffffff' });
  }

  update() {
    // TODO: update pergerakan player & animasi
  }
}
