import Phaser from 'phaser';

/**
 * Kitchen
 * Scene Kitchen — folder home.
 *
 * Status: stub scene — siap diisi tilemap, NPC, dan event dialog.
 */
export default class Kitchen extends Phaser.Scene {
  constructor() {
    super({ key: 'kitchen' });
  }

  preload() {
    // TODO: load tileset/tilemap/sprite khusus scene ini
  }

  create() {
    // TODO: bangun map, spawn player, daftarkan NPC/event interaksi
    this.add.text(16, 16, 'Kitchen (stub)', { fontSize: '16px', color: '#ffffff' });
  }

  update() {
    // TODO: update pergerakan player & animasi
  }
}
