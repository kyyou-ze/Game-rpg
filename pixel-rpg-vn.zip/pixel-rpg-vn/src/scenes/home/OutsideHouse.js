import Phaser from 'phaser';

/**
 * OutsideHouse
 * Scene OutsideHouse — folder home.
 *
 * Status: stub scene — siap diisi tilemap, NPC, dan event dialog.
 */
export default class OutsideHouse extends Phaser.Scene {
  constructor() {
    super({ key: 'outside-house' });
  }

  preload() {
    // TODO: load tileset/tilemap/sprite khusus scene ini
  }

  create() {
    // TODO: bangun map, spawn player, daftarkan NPC/event interaksi
    this.add.text(16, 16, 'OutsideHouse (stub)', { fontSize: '16px', color: '#ffffff' });
  }

  update() {
    // TODO: update pergerakan player & animasi
  }
}
