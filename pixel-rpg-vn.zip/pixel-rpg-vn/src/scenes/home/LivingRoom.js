import Phaser from 'phaser';

/**
 * LivingRoom
 * Scene LivingRoom — folder home.
 *
 * Status: stub scene — siap diisi tilemap, NPC, dan event dialog.
 */
export default class LivingRoom extends Phaser.Scene {
  constructor() {
    super({ key: 'living-room' });
  }

  preload() {
    // TODO: load tileset/tilemap/sprite khusus scene ini
  }

  create() {
    // TODO: bangun map, spawn player, daftarkan NPC/event interaksi
    this.add.text(16, 16, 'LivingRoom (stub)', { fontSize: '16px', color: '#ffffff' });
  }

  update() {
    // TODO: update pergerakan player & animasi
  }
}
