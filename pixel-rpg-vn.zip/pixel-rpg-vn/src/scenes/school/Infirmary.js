import Phaser from 'phaser';

/**
 * Infirmary
 * Scene Infirmary — folder school.
 *
 * Status: stub scene — siap diisi tilemap, NPC, dan event dialog.
 */
export default class Infirmary extends Phaser.Scene {
  constructor() {
    super({ key: 'infirmary' });
  }

  preload() {
    // TODO: load tileset/tilemap/sprite khusus scene ini
  }

  create() {
    // TODO: bangun map, spawn player, daftarkan NPC/event interaksi
    this.add.text(16, 16, 'Infirmary (stub)', { fontSize: '16px', color: '#ffffff' });
  }

  update() {
    // TODO: update pergerakan player & animasi
  }
}
