import Phaser from 'phaser';
import DialogueSystem from '../../systems/DialogueSystem.js';
import DialogueBox from '../../ui/DialogueBox.js';
import chapter1 from '../../data/dialogue/chapter1.json';
import { SCENE_KEYS } from '../../core/Constants.js';

export default class Classroom extends Phaser.Scene {
  constructor() {
    super({ key: SCENE_KEYS.CLASSROOM });
  }

  create() {
    this.add.rectangle(0, 0, this.scale.width, this.scale.height, 0x2b2b45).setOrigin(0);
    this.add.text(20, 20, 'Ruang Kelas — Chapter 1', { fontSize: '14px', color: '#ffffff' });

    this.dialogueBox = new DialogueBox(this);
    this.dialogue = new DialogueSystem(this, this.registry.get('relationship'));
    this.dialogue.load(chapter1.classroom);

    this.dialogue.onLine = (line) => {
      this.dialogueBox.show(line.speaker, line.text);
    };
    this.dialogue.onEnd = () => {
      this.dialogueBox.hide();
      this.time.delayedCall(400, () => this.scene.start(SCENE_KEYS.ROOFTOP));
    };

    this.input.on('pointerdown', () => this.dialogue.next());
    this.dialogue.start();
  }
}
