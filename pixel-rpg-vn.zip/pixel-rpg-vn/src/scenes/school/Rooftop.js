import Phaser from 'phaser';
import DialogueSystem from '../../systems/DialogueSystem.js';
import DialogueBox from '../../ui/DialogueBox.js';
import ChoiceBox from '../../ui/ChoiceBox.js';
import chapter1 from '../../data/dialogue/chapter1.json';
import chapter4 from '../../data/dialogue/chapter4.json';
import SaveManager from '../../core/SaveManager.js';
import EndingSystem from '../../systems/EndingSystem.js';
import { SCENE_KEYS } from '../../core/Constants.js';

/**
 * Rooftop
 * Dipakai ulang di dua momen cerita:
 *  - Chapter 1: dialog "langit sore" pertama (set SW_LangitSore)
 *  - Chapter 4: adegan hujan setelah festival (rooftopRain), lalu
 *    lanjut ke penghitungan ending
 * Perilaku ditentukan dari registry.get('chapter').
 */
export default class Rooftop extends Phaser.Scene {
  constructor() {
    super({ key: SCENE_KEYS.ROOFTOP });
  }

  create() {
    const chapter = this.registry.get('chapter') || 1;
    const isRain = chapter >= 4;

    this.add.rectangle(0, 0, this.scale.width, this.scale.height, isRain ? 0x555577 : 0xffb877).setOrigin(0);
    this.add.text(20, 20, isRain ? 'Atap Sekolah — Hujan' : 'Atap Sekolah — Senja', {
      fontSize: '14px',
      color: isRain ? '#ffffff' : '#3a2a1a'
    });

    const relationship = this.registry.get('relationship');

    this.dialogueBox = new DialogueBox(this);
    this.choiceBox = new ChoiceBox(this);
    this.dialogue = new DialogueSystem(this, relationship);
    this.dialogue.load(isRain ? chapter4.rooftopRain : chapter1.rooftop);

    this.dialogue.onLine = (line) => {
      this.choiceBox.hide();
      this.dialogueBox.show(line.speaker, line.text);
    };

    this.dialogue.onChoice = (line) => {
      this.dialogueBox.hide();
      this.choiceBox.show(line.choice, (i) => this.dialogue.choose(i));
    };

    this.dialogue.onEnd = () => {
      this.dialogueBox.hide();
      this.choiceBox.hide();

      if (isRain) {
        const endingId = EndingSystem.resolve(relationship);
        const nextKey = EndingSystem.sceneKeyFor(endingId);
        SaveManager.save({ chapter: 5, ending: endingId, ...relationship.toJSON() });
        this.time.delayedCall(500, () => this.scene.start(nextKey));
      } else {
        this.registry.set('chapter', 2);
        SaveManager.save({ chapter: 2, ...relationship.toJSON() });
        this.time.delayedCall(400, () => this.scene.start(SCENE_KEYS.CAFETERIA));
      }
    };

    this.input.on('pointerdown', () => this.dialogue.next());
    this.dialogue.start();
  }
}
