import Phaser from 'phaser';
import DialogueSystem from '../../systems/DialogueSystem.js';
import DialogueBox from '../../ui/DialogueBox.js';
import ChoiceBox from '../../ui/ChoiceBox.js';
import chapter3 from '../../data/dialogue/chapter3.json';
import SaveManager from '../../core/SaveManager.js';
import { SCENE_KEYS } from '../../core/Constants.js';

export default class Hallway extends Phaser.Scene {
  constructor() {
    super({ key: SCENE_KEYS.HALLWAY });
  }

  create() {
    this.add.rectangle(0, 0, this.scale.width, this.scale.height, 0x44445a).setOrigin(0);
    this.add.text(20, 20, 'Koridor Sekolah — Chapter 3', { fontSize: '14px', color: '#ffffff' });

    const relationship = this.registry.get('relationship');

    this.dialogueBox = new DialogueBox(this);
    this.choiceBox = new ChoiceBox(this);
    this.dialogue = new DialogueSystem(this, relationship);
    this.dialogue.load(chapter3.hallway);

    this.dialogue.onLine = (line) => {
      this.choiceBox.hide();
      this.dialogueBox.show(line.speaker, line.text);
    };
    this.dialogue.onChoice = (line) => {
      this.dialogueBox.hide();
      this.choiceBox.show(line.choice, (i) => this.dialogue.choose(i));
    };
    this.dialogue.onEnd = () => {
      this.dialogueBox.hide();
      this.choiceBox.hide();
      this.registry.set('chapter', 4);
      SaveManager.save({ chapter: 4, ...relationship.toJSON() });
      this.time.delayedCall(400, () => this.scene.start(SCENE_KEYS.FESTIVAL));
    };

    this.input.on('pointerdown', () => this.dialogue.next());
    this.dialogue.start();
  }
}
