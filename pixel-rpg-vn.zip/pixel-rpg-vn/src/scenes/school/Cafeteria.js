import Phaser from 'phaser';
import DialogueSystem from '../../systems/DialogueSystem.js';
import DialogueBox from '../../ui/DialogueBox.js';
import ChoiceBox from '../../ui/ChoiceBox.js';
import chapter2 from '../../data/dialogue/chapter2.json';
import SaveManager from '../../core/SaveManager.js';
import { SCENE_KEYS } from '../../core/Constants.js';

const OPTIONAL_SPOTS = [
  { key: 'vending', label: 'Vending Machine', x: 100, y: 120, color: 0x4488cc },
  { key: 'kantin', label: 'Meja Kantin', x: 260, y: 120, color: 0xcc8844 },
  { key: 'cleaning', label: 'Piket Kelas', x: 420, y: 120, color: 0x66aa66 },
  { key: 'busStop', label: 'Halte Bus', x: 550, y: 120, color: 0x9966cc }
];

export default class Cafeteria extends Phaser.Scene {
  constructor() {
    super({ key: SCENE_KEYS.CAFETERIA });
  }

  create() {
    this.add.rectangle(0, 0, this.scale.width, this.scale.height, 0x3a3a55).setOrigin(0);
    this.add.text(20, 20, 'Kantin & Sekolah — Chapter 2', { fontSize: '14px', color: '#ffffff' });
    this.add.text(20, 40, 'Kunjungi tempat opsional (kotak warna) sebelum lanjut cerita utama.', {
      fontSize: '11px', color: '#cccccc'
    });

    this.relationship = this.registry.get('relationship');
    this.visited = new Set();

    this.dialogueBox = new DialogueBox(this);
    this.choiceBox = new ChoiceBox(this);

    this._spawnOptionalSpots();
    this._spawnMainTrigger();
  }

  _spawnOptionalSpots() {
    OPTIONAL_SPOTS.forEach((spot) => {
      const box = this.add.rectangle(spot.x, spot.y, 90, 50, spot.color, 0.85)
        .setInteractive({ useHandCursor: true });
      this.add.text(spot.x, spot.y, spot.label, {
        fontSize: '10px', color: '#ffffff', align: 'center', wordWrap: { width: 80 }
      }).setOrigin(0.5);

      box.on('pointerdown', () => {
        if (this.dialogueActive) return;
        this._playOptional(spot.key, box);
      });
    });
  }

  _spawnMainTrigger() {
    const btn = this.add.text(this.scale.width / 2, 220, '[ Lanjutkan cerita utama ]', {
      fontSize: '14px', color: '#ffd479'
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });

    btn.on('pointerdown', () => {
      if (this.dialogueActive) return;
      btn.destroy();
      this._playMain();
    });
  }

  _playOptional(spotKey, box) {
    if (this.visited.has(spotKey)) return;
    this.visited.add(spotKey);
    box.setAlpha(0.4);

    this.dialogueActive = true;
    const dialogue = new DialogueSystem(this, this.relationship);
    dialogue.load(chapter2.optionalEvents[spotKey]);
    dialogue.onLine = (line) => this.dialogueBox.show(line.speaker, line.text);
    dialogue.onEnd = () => {
      this.dialogueBox.hide();
      this.relationship.add('affinity', 1);
      this.dialogueActive = false;
    };

    const handler = () => dialogue.next();
    this.input.on('pointerdown', handler, this);
    dialogue.onEnd = ((orig) => () => { orig(); this.input.off('pointerdown', handler, this); })(dialogue.onEnd);

    dialogue.start();
  }

  _playMain() {
    this.dialogueActive = true;
    const dialogue = new DialogueSystem(this, this.relationship);
    dialogue.load(chapter2.cafeteria);

    dialogue.onLine = (line) => {
      this.choiceBox.hide();
      this.dialogueBox.show(line.speaker, line.text);
    };
    dialogue.onChoice = (line) => {
      this.dialogueBox.hide();
      this.choiceBox.show(line.choice, (i) => dialogue.choose(i));
    };
    dialogue.onEnd = () => {
      this.dialogueBox.hide();
      this.choiceBox.hide();
      this.registry.set('chapter', 3);
      SaveManager.save({ chapter: 3, ...this.relationship.toJSON() });
      this.time.delayedCall(400, () => this.scene.start(SCENE_KEYS.HALLWAY));
    };

    this.input.on('pointerdown', () => dialogue.next());
    dialogue.start();
  }
}
