import Phaser from 'phaser';

/**
 * ClubRoom
 * Scene ClubRoom — folder school.
 *
 * Status: stub scene — siap diisi tilemap, NPC, dan event dialog.
 */
export default class ClubRoom extends Phaser.Scene {
  constructor() {
    super({ key: 'club-room' });
  }

  preload() {
    // TODO: load tileset/tilemap/sprite khusus scene ini
  }

  create() {
    // TODO: bangun map, spawn player, daftarkan NPC/event interaksi
    this.add.text(16, 16, 'ClubRoom (stub)', { fontSize: '16px', color: '#ffffff' });
  }

  update() {
    // TODO: update pergerakan player & animasi
  }
}
