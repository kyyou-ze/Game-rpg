import Phaser from 'phaser';

/**
 * Library
 * Scene Library — folder school.
 *
 * Status: stub scene — siap diisi tilemap, NPC, dan event dialog.
 */
export default class Library extends Phaser.Scene {
  constructor() {
    super({ key: 'library' });
  }

  preload() {
    // TODO: load tileset/tilemap/sprite khusus scene ini
  }

  create() {
    // TODO: bangun map, spawn player, daftarkan NPC/event interaksi
    this.add.text(16, 16, 'Library (stub)', { fontSize: '16px', color: '#ffffff' });
  }

  update() {
    // TODO: update pergerakan player & animasi
  }
}
