import Phaser from 'phaser';

/**
 * SchoolGate
 * Scene SchoolGate — folder school.
 *
 * Status: stub scene — siap diisi tilemap, NPC, dan event dialog.
 */
export default class SchoolGate extends Phaser.Scene {
  constructor() {
    super({ key: 'school-gate' });
  }

  preload() {
    // TODO: load tileset/tilemap/sprite khusus scene ini
  }

  create() {
    // TODO: bangun map, spawn player, daftarkan NPC/event interaksi
    this.add.text(16, 16, 'SchoolGate (stub)', { fontSize: '16px', color: '#ffffff' });
  }

  update() {
    // TODO: update pergerakan player & animasi
  }
}
