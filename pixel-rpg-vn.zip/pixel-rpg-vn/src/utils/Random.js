/**
 * Random
 * Helper angka acak (dipakai untuk variasi dialog kecil).
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class Random {
  constructor(...args) {
    this.args = args;
  }


}
