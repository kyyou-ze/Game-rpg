/**
 * Validator
 * Validasi struktur data JSON dialog/karakter.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class Validator {
  constructor(...args) {
    this.args = args;
  }


}
