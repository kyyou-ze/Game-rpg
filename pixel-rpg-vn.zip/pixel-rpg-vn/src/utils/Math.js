/**
 * Math
 * Helper matematika umum (clamp, lerp).
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class Math {
  constructor(...args) {
    this.args = args;
  }


}
