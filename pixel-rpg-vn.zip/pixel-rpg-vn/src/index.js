import Phaser from 'phaser';
import { GameConfig } from './core/Config.js';

import BootScene from './scenes/boot/BootScene.js';
import PreloadScene from './scenes/boot/PreloadScene.js';
import MainMenuScene from './scenes/menu/MainMenuScene.js';
import Classroom from './scenes/school/Classroom.js';
import Rooftop from './scenes/school/Rooftop.js';
import Cafeteria from './scenes/school/Cafeteria.js';
import Hallway from './scenes/school/Hallway.js';
import Festival from './scenes/city/Festival.js';
import TrueEnding from './scenes/endings/TrueEnding.js';
import GoodEnding from './scenes/endings/GoodEnding.js';
import NormalEnding from './scenes/endings/NormalEnding.js';
import BadEnding from './scenes/endings/BadEnding.js';

const config = {
  ...GameConfig,
  scene: [
    BootScene,
    PreloadScene,
    MainMenuScene,
    Classroom,
    Rooftop,
    Cafeteria,
    Hallway,
    Festival,
    TrueEnding,
    GoodEnding,
    NormalEnding,
    BadEnding
  ]
};

// eslint-disable-next-line no-unused-vars
const game = new Phaser.Game(config);
