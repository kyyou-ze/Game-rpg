/**
 * Settings
 * Pengaturan volume, teks speed, dsb.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class Settings {
  constructor(...args) {
    this.args = args;
  }


}
