/**
 * Game
 * Inisialisasi instance Phaser.Game dan daftar semua scene.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class Game {
  constructor(...args) {
    this.args = args;
  }


}
