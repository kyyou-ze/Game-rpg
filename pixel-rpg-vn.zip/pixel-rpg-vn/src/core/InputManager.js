/**
 * InputManager
 * Mapping input keyboard/touch ke aksi game.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class InputManager {
  constructor(...args) {
    this.args = args;
  }


}
