export const TILE_SIZE = 32;

export const SCENE_KEYS = {
  BOOT: 'boot-scene',
  PRELOAD: 'preload-scene',
  MAIN_MENU: 'main-menu',
  CLASSROOM: 'classroom',
  ROOFTOP: 'rooftop',
  CAFETERIA: 'cafeteria',
  HALLWAY: 'hallway',
  FESTIVAL: 'festival',
  ENDING_TRUE: 'ending-true',
  ENDING_GOOD: 'ending-good',
  ENDING_NORMAL: 'ending-normal',
  ENDING_BAD: 'ending-bad'
};

export const FLAGS = {
  LANGIT_SORE: 'SW_LangitSore',
  SADAR_BEKAL: 'SW_SadarBekal',
  SADAR_RUANG_KESEHATAN: 'SW_SadarRuangKesehatan',
  BANTU_CHAPTER3: 'SW_BantuChapter3'
};

export const SAVE_KEY = 'senja-yang-tak-terucap:save';
