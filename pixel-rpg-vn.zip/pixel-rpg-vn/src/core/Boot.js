/**
 * Boot
 * Setup awal sebelum preload (deteksi device, orientasi).
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class Boot {
  constructor(...args) {
    this.args = args;
  }


}
