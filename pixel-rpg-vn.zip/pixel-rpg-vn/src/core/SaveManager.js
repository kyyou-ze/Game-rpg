import { SAVE_KEY } from './Constants.js';

/**
 * SaveManager
 * Simpan/muat progress (chapter, variabel relationship, dan switch/flag)
 * ke localStorage. Dibungkus try/catch supaya aman kalau storage
 * tidak tersedia (mis. mode privat browser).
 */
export default class SaveManager {
  static save(state) {
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(state));
      return true;
    } catch (err) {
      console.warn('SaveManager: gagal menyimpan', err);
      return false;
    }
  }

  static load() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (err) {
      console.warn('SaveManager: gagal memuat', err);
      return null;
    }
  }

  static clear() {
    try {
      localStorage.removeItem(SAVE_KEY);
    } catch (err) {
      console.warn('SaveManager: gagal menghapus save', err);
    }
  }

  static defaultState() {
    return {
      chapter: 1,
      trust: 0,
      affinity: 0,
      courage: 0,
      flags: {
        SW_LangitSore: false,
        SW_SadarBekal: false,
        SW_SadarRuangKesehatan: false,
        SW_BantuChapter3: false
      }
    };
  }
}
