/**
 * Preload
 * Preload aset global (font, UI, spritesheet umum).
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class Preload {
  constructor(...args) {
    this.args = args;
  }


}
