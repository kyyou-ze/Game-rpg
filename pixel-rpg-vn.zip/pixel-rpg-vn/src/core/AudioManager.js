/**
 * AudioManager
 * Kontrol BGM, ambience, dan SFX terpusat.
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class AudioManager {
  constructor(...args) {
    this.args = args;
  }


}
