/**
 * Localization
 * Sistem teks multi-bahasa (ID default).
 *
 * Status: stub — kerangka awal, logika detail menyusul.
 */
export default class Localization {
  constructor(...args) {
    this.args = args;
  }


}
