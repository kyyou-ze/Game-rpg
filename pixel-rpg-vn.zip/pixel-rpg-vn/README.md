# Senja yang Tak Terucap

Visual novel / RPG eksplorasi ringan bergaya sekolah, dibangun dengan **Phaser 3** + **Vite**.

## Status project

Ini kerangka project lengkap (scaffold). **Chapter 1-5 sudah tersambung penuh
dari awal sampai ke salah satu dari 4 ending**, mengikuti alur:

`MainMenu → Classroom (Ch1) → Rooftop (Ch1, set SW_LangitSore) → Cafeteria (Ch2,
dengan 4 event opsional) → Hallway (Ch3, konflik & rumor) → Festival (Ch4,
memory payoff langit sore) → Rooftop (Ch4, hujan & pengakuan rahasia) →
EndingSystem.resolve() → salah satu dari TrueEnding / GoodEnding /
NormalEnding / BadEnding`

Variabel Trust/Affinity/Courage dan flag memory (`SW_LangitSore`,
`SW_BantuChapter3`, dst) benar-benar mempengaruhi ending mana yang keluar,
sudah diverifikasi lewat simulasi terpisah untuk tiga skenario pemain.

Yang masih berupa **stub kosong** (kerangka kelas/scene siap diisi, ditandai
`TODO`): semua folder aset (`sprites`, `tilesets`, `audio`, `portraits`, `cg`),
sistem sekunder yang tidak dipakai jalur cerita utama (Inventory, Phone,
Weather, Calendar, Achievement), serta scene lokasi tambahan yang belum
dipakai naskah (Library, Gym, Park, Shrine, dst — disiapkan untuk
pengembangan konten opsional lanjutan).

### Keterbatasan verifikasi

Sandbox pembuatan project ini tidak punya akses internet, jadi `npm install`
dan `npm run build` belum bisa dijalankan langsung di sini. Yang sudah
diverifikasi: seluruh file `.js` lolos `node --check` (sintaks valid), seluruh
file `.json` valid, dan logika `EndingSystem` sudah disimulasikan manual untuk
tiga skenario (best-case → True Happy End, mixed → Happy End, worst-case →
Sad End). Jalankan `npm install && npm run dev` di komputermu untuk verifikasi
render sungguhan di browser.

Baca dokumen desain cerita lengkap di `docs/` dan `desain-cerita-dan-gameplay.md`
(kalau kamu simpan di root project) untuk detail naskah, karakter, dan sistem
ending.

## Menjalankan project

```bash
npm install
npm run dev      # jalankan dev server (default di localhost:5173)
npm run build    # build produksi ke folder dist/
npm run preview  # preview hasil build
```

## Struktur singkat

```
src/
├── core/        konfigurasi Phaser, save manager, konstanta
├── data/        JSON karakter, dialog per chapter, aturan ending
├── systems/     DialogueSystem, RelationshipSystem, EndingSystem, dll
├── managers/    asset/audio/UI manager tingkat aplikasi
├── ui/          DialogueBox, ChoiceBox, menu-menu
├── entities/    Player, NPC, objek interaktif
└── scenes/      boot, menu, school, city, home, endings
```

## Cara bermain (prototype saat ini)

1. `npm run dev`, buka browser ke alamat yang muncul di terminal
2. Klik "Mulai Cerita" di menu utama
3. Klik di mana saja untuk memajukan dialog di Ruang Kelas
4. Di Atap Sekolah, dialog akan berhenti di satu titik pilihan — klik salah
   satu opsi untuk melanjutkan
5. Setelah Chapter 1 selesai, progres otomatis tersimpan ke `localStorage`

## Menambah aset asli

Ganti placeholder di `public/assets/` (sprite, tileset, portrait, audio)
lalu update referensi path di scene terkait (`src/scenes/**`) dan
`AssetManager.js`. Lisensi tiap aset pihak ketiga wajib dicatat di
`docs/changelog.md` sebelum dipakai.

## Menambah chapter baru

1. Tambah file dialog baru di `src/data/dialogue/chapterN.json` mengikuti
   format `chapter1.json` (array baris `{ speaker, text }` atau `{ choice }`)
2. Buat/gunakan scene yang sesuai di `src/scenes/`
3. Load script lewat `DialogueSystem`, sambungkan efek pilihan ke
   `RelationshipSystem`
4. Untuk chapter terakhir, panggil `EndingSystem.resolve()` untuk menentukan
   scene ending yang dituju
